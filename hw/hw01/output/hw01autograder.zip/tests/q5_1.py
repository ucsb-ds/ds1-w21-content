test = {   'name': 'q5_1',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> 1 <= survivor_answer <= 3\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
