test = {'name': 'q1_5', 'points': 1, 'suites': [{'cases': [], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
